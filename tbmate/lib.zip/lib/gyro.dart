import 'package:flutter/foundation.dart';
import 'package:web_socket_channel/io.dart';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:velocity_x/velocity_x.dart';
import 'dart:async';
import 'package:aeyrium_sensor/aeyrium_sensor.dart';

double gyroX = 0.0;
double gyroY = 0.0;
var i = 0;
String schannel;

class Gacce extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyHomePage(
        channel: IOWebSocketChannel.connect('wss://tbmatekl.com/wss2/NNN'),
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  final WebSocketChannel channel;

  MyHomePage({Key key, @required this.channel}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  StreamSubscription<dynamic> _streamSubscriptions;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: FlatButton(
          child: "Start the game".text.color(Colors.red).bold.makeCentered(),
          onPressed: _sendMessage,
        )
            .centered()
            .shimmer(primaryColor: Colors.grey, secondaryColor: Colors.amber),
      ),
      //     floatingActionButton: FloatingActionButton(
      //   onPressed: _sendMessage,
      //   tooltip: 'Send message',
      //   child: Icon(Icons.send),
      // )
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }

  void _sendMessage() {
    if (i == 0) {
      print("subscribing..");
      widget.channel.sink.add('{"command":"subscribe", "channel":"$schannel"}');
      i = 1;
    } else {
      print("messaging..");

      _streamSubscriptions = AeyriumSensor.sensorEvents.listen((event) {
        var x = event.roll * -2.5;
        var y = event.pitch * 2.5;

        // for (var i = 20000; i > 0; i--) {}
        widget.channel.sink.add(
            '{"command": "message", "message": "${x.toStringAsFixed(1)},${y.toStringAsFixed(1)}"}');
      });

      // Future.delayed(const Duration(milliseconds: 100), () {
      // });
    }
  }

  @override
  void dispose() {
    widget.channel.sink.close();
    super.dispose();
  }
}

// String schannel;

// // void main() => runApp(new MyApp());

// class App extends StatefulWidget {
//   @override
//   _AppState createState() => new _AppState();
// }

// class _AppState extends State<App> {
//   String _data = "";

//   StreamSubscription<dynamic> _streamSubscriptions;

//   @override
//   void initState() {
//     _streamSubscriptions = AeyriumSensor.sensorEvents.listen((event) {
//       setState(() {
//         _data = "Pitch ${event.pitch} , Roll ${event.roll}";
//       });
//     });
//     super.initState();
//   }

//   @override
//   void dispose() {
//     if (_streamSubscriptions != null) {
//       _streamSubscriptions.cancel();
//     }
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return new MaterialApp(
//       home: new Scaffold(
//         appBar: new AppBar(
//           title: const Text('Plugin example app'),
//         ),
//         body: Padding(
//           padding: const EdgeInsets.all(15.0),
//           child: new Center(
//             child: new Text('Device : $_data'),
//           ),
//         ),
//       ),
//     );
//   }
// }
