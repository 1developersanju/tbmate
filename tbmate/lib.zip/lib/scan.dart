import 'package:barcode_scan/barcode_scan.dart';
import 'package:flutter/material.dart';
import 'package:qr_scanner/gyro.dart';
import 'package:velocity_x/velocity_x.dart';
import 'package:aeyrium_sensor/aeyrium_sensor.dart';

class ScanPage extends StatefulWidget {
  @override
  _ScanPageState createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage> {
  String qrCodeResult = "Scan to show result";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black87,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("Scanner"),
        centerTitle: true,
      ),
      body: Container(
        child: FlatButton(
                child: "Tap here to scan".text.bold.makeCentered(),
                onPressed: () async {
                  String codeScanner = await BarcodeScanner.scan();
                  schannel = codeScanner.substring(codeScanner.length - 12);
                  Navigator.pushReplacement(context,
                      MaterialPageRoute(builder: (context) => Gacce()));
                })
            .circle(radius: 200, backgroundColor: Colors.black12)
            .shimmer(primaryColor: Colors.black12, secondaryColor: Colors.red)
            .centered(),
      ),
    );
  }
}

// FlatButton(
//         onPressed: () async {
//           String codeSanner = await BarcodeScanner.scan();
//           setState(() {
//             schannel = codeScanner.substring(codeSanner.length - 12);
//           });
//         },
// void g(){
//   String codeSanner = await BarcodeScanner.scan();
//           setState(() {
//             qrCodeResult = codeSanner.substring(codeSanner.length - 12);
//           });
// }
